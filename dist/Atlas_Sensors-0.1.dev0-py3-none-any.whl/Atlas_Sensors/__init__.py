from .smbus import AtlasSMBus
name = "Atlas_Sensors"